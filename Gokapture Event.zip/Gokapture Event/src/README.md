# Task Management System

A RESTful API for a task management system that supports user registration, authentication, task management, and task filtering/searching.

## Features

- User registration and authentication with JWT.
- CRUD operations for tasks.
- Task assignment to users.
- Filtering and searching tasks by status, priority, and due date.
- Dockerized for easy setup and deployment.

## Tech Stack

- **Node.js**: JavaScript runtime environment.
- **Express.js**: Web framework for Node.js.
- **Sequelize**: ORM for database operations.
- **PostgreSQL**: Relational database.
- **JWT**: Authentication via JSON Web Tokens.
- **Docker**: Containerization of the application.

## Getting Started

### Prerequisites

Ensure you have the following installed on your machine:

- Node.js (v18 or higher)
- Docker (if using Docker for setup)
- PostgreSQL (if not using Docker for the database)

### Installation

1. **Clone the repository:**
   ```bash
   git clone https://github.com/yourusername/task-management-system.git
   cd task-management-system
